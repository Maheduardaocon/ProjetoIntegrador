import 'package:flutter/material.dart';

class Bolo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: BackgroundImageScreen(),
    );
  }
}

class BackgroundImageScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Imagem de fundo
          Positioned.fill(
            child: Image.asset(
              'assets/Bolos.PNG', // Caminho da imagem no projeto
              fit: BoxFit.cover, // Ajuste da imagem
            ),
          ),
          // Conteúdo sobre a imagem de fundo
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(height: 20),
              ],
            ),
          ),
        ],
      ),
    );
  }
}